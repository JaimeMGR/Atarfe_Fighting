<?php
    $nombre_host='localhost';
    $nombre_usuario='root';
    $password_db='';
    $nombre_db="clubdeportivo";
    $tabla_productos='productos';
    //poner el nombre de las tablas si hubiera mas
?>